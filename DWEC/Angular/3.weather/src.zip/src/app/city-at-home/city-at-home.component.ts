import { Component } from '@angular/core';

@Component({
  selector: 'app-city-at-home',
  imports: [],
  templateUrl: './city-at-home.component.html',
  styles: ``
})
export class CityAtHomeComponent {

}
