import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  imports: [],
  templateUrl: './header.component.html',
  styles: `
    div {
      background-color: rgb(240, 240, 240);
    }
  `
})
export class HeaderComponent {

}
